# 2023-09-14
add folder topic_01
add solution for task1 task2 and task3

# 2023-09-22
add folder topic_02
add solution for task1 task2 and task3

# 2023-10-02
add folder topic_03
add solution for task1 task2 task3 & task4

# 2023-10-09
add folder topic_044
add solution for task1 task2 


#2023-10-16
add folder topic_05
add solutins for task1 task2 and task3 functions.py calc.py operations.py


#2023-10-25
add folder topic_06
add solutins for task2 and task: functions.py calc.py operations.py

# Is it really Oct 10
add folder topic_07
add solution for task1 task2and task3

# 2023-11-02
add new branch 
and add changes to the README file

# TP-KB-222-Kateryna-Kutsyn
